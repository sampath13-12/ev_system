package com.ev_centers.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EvCentersBillingSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
