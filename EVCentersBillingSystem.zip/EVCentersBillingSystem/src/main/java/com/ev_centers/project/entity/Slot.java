package com.ev_centers.project.entity;


import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
public class Slot {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String location;

    private String timeSlot;

    @ManyToOne
    @JoinColumn(name = "ev_owner_id")
    private EvOwner evOwner; // Owner of the slot



}
