package com.ev_centers.project.service;

import com.ev_centers.project.entity.Slot;
import com.ev_centers.project.repository.SlotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class SlotService {
    @Autowired
    private SlotRepository slotRepository;

    public Slot getSlotById(Long slotId) {
        return slotRepository.findById(slotId).orElse(null);
    }

    public Slot saveSlot(Slot newSlot) {
        return slotRepository.save(newSlot);
    }
}
